from django.urls import path
from AppCoco.views import *

urlpatterns = [
    path('',inicio,name= 'Inicio'),
    path('autos/',autos,name= 'Autos'),
    path('clientes/',clientes,name= 'Clientes'),
    path('empleados/',empleados,name= 'Empleados'),
    path('autosFormulario/',autosFormulario,name='AutosFormulario'),
    path('clienteFormulario/',clienteFormulario,name='ClienteFormulario'),
    path('empleadoFormulario/',empleadoFormulario,name='EmpleadoFormulario'),
    path('buscaAutos/',buscaAutos, name='BuscadorAutos'),
    path('buscar/',buscar)
    


]