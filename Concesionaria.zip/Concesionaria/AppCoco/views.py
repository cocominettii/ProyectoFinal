from re import L
from django.http import HttpResponse
from django.shortcuts import render

from AppCoco.forms import *
from AppCoco.models import Auto, Cliente, Empleado

from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, authenticate
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required

from django.views.generic import ListView
from django.views.generic import DetailView
from django.views.generic.edit import CreateView, UpdateView ,DeleteView

# Create your views here.
def inicio(request):
    return render(request, 'AppCoco/inicio.html')
    
def autos(request):
    
    return render(request,'AppCoco/autos.html')

def empleados(request):
    return render(request,'AppCoco/empleados.html')
    
def clientes(request):
    return render(request,'AppCoco/clientes.html')

def about(request):
    return render(request,'AppCoco/about.html')

def vacio(request):
    return render(request, 'AppCoco/vacio.html')

    
def autosFormulario(request):
    
    
    if request.method == 'POST':

        mi_formulario = AutosFormulario(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            auto = Auto(marca = informacion["marca"], modelo = informacion["modelo"], motor = informacion["motor"])
            auto.save()

            return render(request,'AppCoco/inicio.html')
    else:
        mi_formulario =AutosFormulario()
        return render(request, 'AppCoco/autosFormulario.html',{"mi_formulario": mi_formulario})


@login_required
def clienteFormulario(request):

    if request.method == 'POST':

        mi_formulario = ClienteFormulario(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            cliente = Cliente(nombre = informacion["nombre"],apellido = informacion["apellido"],email = informacion["email"])
            cliente.save()

            return render(request,'AppCoco/inicio.html')
    else:
        mi_formulario =ClienteFormulario()
        return render(request, 'AppCoco/clienteFormulario.html',{"mi_formulario": mi_formulario})

@login_required
def empleadoFormulario(request):

    if request.method == 'POST':

        mi_formulario = EmpleadoFormulario(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            empleado = Empleado(nombre = informacion["nombre"],apellido = informacion["apellido"],email = informacion["email"],encargo = informacion["encargo"])
            empleado.save()

            return render(request,'AppCoco/inicio.html')
    else:
        mi_formulario =EmpleadoFormulario()
        return render(request, 'AppCoco/empleadoFormulario.html',{"mi_formulario": mi_formulario})

def buscaAutos(request):
    return render(request,'AppCoco/buscaAutos.html')

def buscar(request):
    if request.GET['marca']:

        #respuesta = f"Estoy buscando autos marca {request.GET['marca']}"

        marca= request.GET['marca']
        autos = Auto.objects.filter(marca=marca)

        return render(request,'AppCoco/resultadosBusqueda.html',{'autos': autos , "marca":marca})
    else:
        respuesta = "No enviaste datos"
        return HttpResponse(respuesta)



def buscaClientes(request):
    return render(request,'AppCoco/buscaClientes.html')

def buscar_c(request):
    if request.GET['apellido']:

        #respuesta = f"Estoy buscando autos marca {request.GET['marca']}"

        apellido= request.GET['apellido']
        clientes = Cliente.objects.filter(apellido=apellido)

        return render(request,'AppCoco/resultadosBusqueda_c.html',{'clientes': clientes , "apellido": apellido})
    else:
        respuesta = "No enviaste datos"
        return HttpResponse(respuesta)



def buscaEmpleados(request):
    return render(request,'AppCoco/buscaEmpleados.html')

def buscar_e(request):
    if request.GET['encargo']:

        #respuesta = f"Estoy buscando autos marca {request.GET['marca']}"

        encargo= request.GET['encargo']
        empleados = Empleado.objects.filter(encargo=encargo)

        return render(request,'AppCoco/resultadosBusqueda_e.html',{'empleados': empleados , "encargo": encargo})
    else:
        respuesta = "No enviaste datos"
        return HttpResponse(respuesta)


def listaAutos(request):

    autos = Auto.objects.all()

    contexto = {'autos':autos}

    return render(request, 'AppCoco/listaAutos.html',contexto)

def listaEmpleados(request):

    empleados = Empleado.objects.all()

    contexto = {'empleados':empleados}

    return render(request, 'AppCoco/listaEmpleados.html',contexto)

def listaClientes(request):

    clientes = Cliente.objects.all()

    contexto = {'clientes':clientes}

    return render(request, 'AppCoco/listaClientes.html',contexto)



def login_request(request):

    if request.method == 'POST':
        
        form = AuthenticationForm(request,data = request.POST)

        if form.is_valid():

            data = form.cleaned_data

            

            user = authenticate(username = data["username"] , password = data["password"])


            if user is not True:
            
                login(request,user)

                return render(request, 'AppCoco/inicio.html', {'mensaje': f'Bienvenido {user.get_username()}'} )
            
            else:
                return render(request,'AppCoco/inicio.html', {'mensaje':'Error, Datos incorrectos'})

        else:
            return render(request, 'AppCoco/inicio.html', {'mensaje': 'Error, Formulario erroneo'})
    else:
        form = AuthenticationForm()

    return render(request, 'AppCoco/login.html',{'form':form})


def register(request):

    if request.method == 'POST':

        form = UserCreationForm(request.POST)

        if form.is_valid():

            username = form.cleaned_data['username']
            form.save()

            return render(request, 'AppCoco/inicio.html', {'mensaje':'Usuario Creado Exitosamente'})
        else:
            return render(request, 'AppCoco/inicio.html', {'mensaje':'Form erroneo (no coinciden probablemente)'})
    else:
        form = UserCreationForm()

        return render(request, 'AppCoco/registro.html', {'form' : form} )



class AutoList(ListView):
    
    model = Auto
    template_name = 'AppCoco/autoList.html'


class AutoDetalle(DetailView):
    
    model = Auto
    template_name = 'AppCoco/autoDetalle.html'

class AutoDelete(LoginRequiredMixin , DeleteView):
    model = Auto
    success_url = '/AppCoco/auto/list/'


class ClienteList(ListView):
    
    model = Cliente
    template_name = 'AppCoco/clienteList.html'


class ClienteDetalle(DetailView):
    
    model = Cliente
    template_name = 'AppCoco/clienteDetalle.html'
