from django.http import HttpResponse
from django.shortcuts import render
from AppCoco.forms import *
from AppCoco.models import Auto, Cliente, Empleado

# Create your views here.
def inicio(request):
    return render(request, 'AppCoco/inicio.html')
    
def autos(request):
    
    return render(request,'AppCoco/autos.html')

def empleados(request):
    return render(request,'AppCoco/empleados.html')
    
def clientes(request):
    return render(request,'AppCoco/clientes.html')


def autosFormulario(request):
    
    
    if request.method == 'POST':

        mi_formulario = AutosFormulario(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            auto = Auto(marca = informacion["marca"],modelo = informacion["modelo"],motor = informacion["motor"])
            auto.save()

            return render(request,'AppCoco/inicio.html')
    else:
        mi_formulario =AutosFormulario()
        return render(request, 'AppCoco/autosFormulario.html',{"mi_formulario": mi_formulario})



def clienteFormulario(request):

    if request.method == 'POST':

        mi_formulario = ClienteFormulario(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            cliente = Cliente(nombre = informacion["nombre"],apellido = informacion["apellido"],email = informacion["email"])
            cliente.save()

            return render(request,'AppCoco/inicio.html')
    else:
        mi_formulario =ClienteFormulario()
        return render(request, 'AppCoco/clienteFormulario.html',{"mi_formulario": mi_formulario})


def empleadoFormulario(request):

    if request.method == 'POST':

        mi_formulario = EmpleadoFormulario(request.POST)

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            empleado = Empleado(nombre = informacion["nombre"],apellido = informacion["apellido"],email = informacion["email"],encargo = informacion["encargo"])
            empleado.save()

            return render(request,'AppCoco/inicio.html')
    else:
        mi_formulario =EmpleadoFormulario()
        return render(request, 'AppCoco/empleadoFormulario.html',{"mi_formulario": mi_formulario})

def buscaAutos(request):
    return render(request,'AppCoco/buscaAutos.html')

def buscar(request):
    if request.GET['marca']:

        #respuesta = f"Estoy buscando autos marca {request.GET['marca']}"

        marca= request.GET['marca']
        autos = Auto.objects.filter(marca=marca)

        return render(request,'AppCoco/resultadosBusqueda.html',{'autos': autos , "marca":marca})
    else:
        respuesta = "No enviaste datos"
        return HttpResponse(respuesta)