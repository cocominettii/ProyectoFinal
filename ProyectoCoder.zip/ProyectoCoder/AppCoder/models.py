from django.db import models

# Create your models here.
class Encargo (models.Model):
    nombre = models.CharField('nombre',max_length=50)
    num_encargo = models.IntegerField()

    def __str__(self):
        return self.nombre

class Cliente (models.Model):
    nombre = models.CharField('nombre', max_length=50)
    apellido =  models.CharField('apellido', max_length=50)
    fecha_encargo = models.DateField('fecha',auto_now=False,auto_now_add=False)

class Empleado (models.Model):
    nombre = models.CharField('Nombre', max_length=50)
    apellido =  models.CharField('Apellido', max_length=50)
    email = models.EmailField()
    Area = models.CharField('Profesion',max_length=40)


    