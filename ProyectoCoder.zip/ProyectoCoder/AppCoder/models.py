from django.db import models

# Create your models here.
class Curso (models.Model):
    nombre = models.CharField('nombre',max_length=50)
    camada = models.IntegerField()

    def __str__(self):
        return self.nombre

class Alumno (models.Model):
    nombre = models.CharField('nombre', max_length=50)
    apellido =  models.CharField('apellido', max_length=50)
    fecha_inscripcion = models.DateField('fecha',auto_now=False,auto_now_add=False)

    def __str__(self):
        return self.nombre, self.apellido

class Profesor (models.Model):
    nombre = models.CharField('Nombre', max_length=50)
    apellido =  models.CharField('Apellido', max_length=50)
    email = models.EmailField()
    profesion = models.CharField('Profesion',max_length=40)

    def __str__(self):
        return self.nombre, self.apellido

class Entregable (models.Model):
    nombre = models.CharField('Nombre', max_length=50)
    fechaDeEntrega =  models.DateField()
    entregado = models.BooleanField()
    