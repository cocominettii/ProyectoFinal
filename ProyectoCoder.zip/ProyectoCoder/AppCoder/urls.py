from django.urls import path

from AppCoder.views import *
    
urlpatterns = [
    path('curso/<name>/<num>',crea_curso),
    path('', inicio, name= 'Inicio'),
    path('cursos/',cursos, name= 'Cursos'),
    path('alumnos/',alumnos, name= 'Alumnos'),
    path('profesores/',profesores, name= 'Profesores'),
    path('entregables/',entregables, name= 'Entregables'),
    path('cursoFormulario/',cursoFormularios, name= 'CursoFormulario'),
    #path('profesorFormulario/',profesorFormulario, name= 'ProfesorFormulario'),
    #path('alumnoFormulario/',alumnoFormulario, name= 'AlumnoFormulario'),
    #path('listaCursos',mostrarCursos, name = 'ListadoCursos'),
    



    
    
]