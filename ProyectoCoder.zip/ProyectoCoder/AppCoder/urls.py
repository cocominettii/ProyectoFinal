from django.urls import path

from AppCoder.views import *
    
urlpatterns = [
    path('curso/<name>/<num>',crea_encargo),
    path('', inicio, name= 'Inicio'),
    path('encargos/',encargos, name= 'Encargos'),
    path('clientes/',clientes, name= 'Clientes'),
    path('empleados/',empleados, name= 'Profesores'),
    path('encargoFormulario/',encargoFormulario, name= 'EncaroFormulario'),
    

    
    
]