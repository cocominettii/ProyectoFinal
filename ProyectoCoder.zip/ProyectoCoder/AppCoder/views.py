

from django.http import HttpResponse
from django.shortcuts import render
from AppCoder.models import *
# Create your views here.


def crea_encargo(self, name, num):
    encargo = Encargo(nombre=name, num_encargo=num)
    encargo.save()

    return HttpResponse(f'se creo el curso de {encargo.nombre} de la camada {encargo.camada}')


def inicio(req):
    return render(req, 'AppCoder/inicio.html')


def clientes(req):
    return render(req, 'AppCoder/clientes.html')


def empleados(req):
    return render(req, 'AppCoder/empleados.html')


def encargos(req):
    return render(req, 'AppCoder/encargos.html')




def encargoFormulario(request):

    if request.method == 'POST':
        encargo = Encargo(nombre=request.POST["curso"],num_encargo=request.POST["Nº encargo"])
        encargo.save()

        return render(request, 'AppCoder/inicio.html')

    return render(request, 'AppCoder/encargoFormulario.html')






# def profesorFormulario(request):

#     # print(request.POST)

#     if request.method == 'POST':
#         curso = Profesor(nombre=request.POST["nombre"], apellido=request.POST["apellido"], email=request.POST["email"], profesion=request.POST["profesion"])

#         curso.save()

#         return render(request, 'AppCoder/inicio.html')

#     return render(request, 'AppCoder/profesorFormulario.html')

