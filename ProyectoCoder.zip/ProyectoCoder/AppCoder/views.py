

from django.http import HttpResponse
from django.shortcuts import render
from AppCoder.models import Alumno, Curso, Profesor
from AppCoder.forms import AlumnoFormulario, CursoFormulario, ProfesorFormulario
# Create your views here.



def crea_curso(self, name, num):
    curso = Curso(nombre=name, camada=num)
    curso.save()

    return HttpResponse(f'se creo el curso de {curso.nombre} de la camada {curso.camada}')


def inicio(req):
    return render(req, 'AppCoder/inicio.html')


def alumnos(req):
    return render(req, 'AppCoder/alumnos.html')


def profesores(req):
    return render(req, 'AppCoder/profesores.html')


def cursos(req):
    return render(req, 'AppCoder/cursos.html')


def entregables(req):
    return render(req, 'AppCoder/entregables.html')


def cursoFormulario(request):
    
    if request.method == 'POST':

        mi_formulario = CursoFormulario(request.POST)
        
        

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            curso = Curso(nombre=informacion["curso"],camada=informacion["camada"])
            curso.save()

            return render(request, 'AppCoder/inicio.html')
        else:
            return HttpResponse('INGRESE PARAMETROS VALIDOS')
    else:
        mi_formulario = CursoFormulario()

    return render(request, 'AppCoder/cursoFormulario.html' , {'form':mi_formulario})




def profesorFormulario(request):
    
    if request.method == 'POST':

        mi_formulario = ProfesorFormulario(request.POST)
        
        

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            profesor = Profesor(nombre=informacion["nombre"], apellido=informacion["apellido"], email =informacion["email"], profesion = informacion["profesion"])
            profesor.save()

            return render(request, 'AppCoder/inicio.html')
        else:
            return HttpResponse('INGRESE PARAMETROS VALIDOS')
    else:
        mi_formulario = ProfesorFormulario()
        


    return render(request, 'AppCoder/profesorFormulario.html' , {'form':mi_formulario})


def alumnoFormulario(request):
    
    if request.method == 'POST':

        mi_formulario = AlumnoFormulario(request.POST)
        
        

        if mi_formulario.is_valid():

            informacion = mi_formulario.cleaned_data

            alumno = Alumno(nombre=informacion["nombre"], apellido=informacion["apellido"], fecha_inscripcion = informacion["fecha_inscripcion"])
            alumno.save()

            return render(request, 'AppCoder/inicio.html')
        else:
            return HttpResponse('INGRESE PARAMETROS VALIDOS')
    else:
        mi_formulario = AlumnoFormulario()
        


    return render(request, 'AppCoder/alumnoFormulario.html' , {'form':mi_formulario})


